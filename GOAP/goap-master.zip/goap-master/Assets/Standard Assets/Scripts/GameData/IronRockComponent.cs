using UnityEngine;
using System.Collections;

public class IronRockComponent : MonoBehaviour
{
}

